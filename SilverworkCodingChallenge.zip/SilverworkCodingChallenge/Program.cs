﻿using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace SilverworkCodingChallenge
{

    class Program
    {

        public static string read (string fileName){
            
            try
            {
             
             string jsonFromFile;
             
             using( var reader = new StreamReader(fileName))
             {
                    jsonFromFile = reader.ReadToEnd();
                    //Console.Write(jsonFromFile);
                    var loansFromJson = JsonConvert.DeserializeObject<Loan>(jsonFromFile);
                    return jsonFromFile;
             }
             
            }

            catch(Exception e)
            {
                Console.Write(e);
            }
            return "didnt work";
            
        }
        
        
        

        static void Main(string[] args)
        {
            read(@"C:\Users\17024\Documents\Silverwork\SilverworkCodingChallenge\loans.json");
            
            //makeNewObject
            //writeJson
            
            //Console.Write("hello world");
        }
    }
}
