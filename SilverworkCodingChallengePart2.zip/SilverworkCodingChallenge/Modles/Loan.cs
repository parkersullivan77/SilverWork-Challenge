
using System;
using System.Diagnostics.CodeAnalysis;

namespace SilverworkCodingChallenge{

public class Loan : IComparable<Loan>
{
      
    public string LoanGuid { get; set; }
    public int LoanId { get; set; }
    public string BorrowerFirstName { get; set; }
    public string BorrowerLastName { get; set;}
    public string SubjectAddress1 { get; set; }
    public string SubjectAddress2 { get; set; }
    public string SubjectCity { get; set; }
    public string SubjectState{ get; set; }
    public string SubjectZip { get; set; }
    public float SubjectAppraisedAmount { get; set; }
    public float LoanAmount { get; set; }
    public float InterestRate { get; set; }

    public int CompareTo([AllowNull] Loan other)
        {
            if(LoanAmount > other.LoanAmount){
                return 1;
            }
            if(LoanAmount < other.LoanAmount){
                return -1;
            }
            if(LoanAmount == other.LoanAmount){
                return 0;
            }
            return 0;
        }
    }
}