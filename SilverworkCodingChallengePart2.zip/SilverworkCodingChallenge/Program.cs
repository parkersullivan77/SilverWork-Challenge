﻿using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace SilverworkCodingChallenge
{

    class Program
    {

        public static List<Loan> read (string fileName){
            
            try
            {
             
             string jsonFromFile;
             
             using( var reader = new StreamReader(fileName))
             {
                    jsonFromFile = reader.ReadToEnd();
                    //Console.Write(jsonFromFile);
                    List<Loan> loansFromJson = JsonConvert.DeserializeObject<List<Loan>>(jsonFromFile);
                    //Console.Write(loansFromJson[0].BorrowerFirstName);
                    return loansFromJson;
             }
             
            }

            catch(Exception e)
            {
                Console.Write(e);
            }
            List<Loan> nn = new List<Loan>();
            return nn;
            
        }

        static public Summary computeLoanSummary(List<Loan> loans){
            Summary summary = new Summary();
            double sum = 0;
            int count = 0;
            double avg=0;
            double min = 1000000000;
            double max = 0;

            foreach (Loan loan in loans){
                sum += loan.LoanAmount;
                count ++;
                if(loan.LoanAmount < min){
                    min = loan.LoanAmount;
                }
                if(loan.LoanAmount > max){
                    max = loan.LoanAmount;
                }
            }
            
            loans.Sort();
            int medianIndex = loans.Count/2;
            int medianIndex1 = medianIndex+1;
            double med = (loans[medianIndex].LoanAmount + loans[medianIndex1].LoanAmount) /2;          
            avg = sum/count; 
            
            Console.Write( sum + " " + avg + " " + max + " " + min + " "  + med);

            summary.Sum = sum;
            summary.Average = avg;
            summary.Minimum = min;
            summary.Maximum = max;
            summary.Median = med;
            
            
            return summary;

        }

        
        
        

        static void Main(string[] args)
        {
            List<Loan> loans = new List<Loan>();
            Summary loanSummary = new Summary();
        
            loans = read(@"C:\Users\17024\Documents\Silverwork\SilverworkCodingChallenge\loans.json");
            loanSummary = computeLoanSummary(loans);

        }
    }
}
